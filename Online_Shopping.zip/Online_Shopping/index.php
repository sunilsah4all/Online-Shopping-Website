<html>
<?php
error_reporting(1);
include("index1.php");
?>
<title>Online Shopping</title>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link rel="stylesheet" type="text/css" href="default.css" title="default">
</head>
<body>
<div id="WholePage">
<div id="Inner">
<div id="Container" style="border:groove;border-color:#00CCFF">
<div id="Head">
<div id="Head_left">
<div id="Leaf_top"><img src="newpics/r9.jpg" width="324" /></div>
<div id="Leaf_bottom"> <a class="registration" href="index.php?con=11">REGISTERATION</a><a class="log-in" href="index.php?con=12">LOG IN</a> </div>
</div>
<div id="Head_right">
<div id="Logo">
<div id="Name">
<span class="blue">C</span><span>lickshop</span></span>
</div>
<div id="Informations">&nbsp&nbspExclusive Clothing Fashion</div>
</div>
<div id="Top_menu">
<a class="kart" href="?page=home"><span>CART</span></a>
<a class="orders" href="index.php?con=3"><span>GALLERY</span></a>
<a class="contact" href="index.php?con=1"><span>CONTACT</span></a>
<a class="help" href="index.php?con=2"><span>ABOUT US</span></a>
<a class="home" href="?page=home"><span>HOME</span></a>
</div>
</div>
</div>
<div id="CentralPart">
<div id="LeftPart">
<div id="Menu">
<div id="Menu_header">
<div class="menu_header_left">
<span class="menu_text"><font face="Georgia, Times New Roman, Times, serif">Search</font></span>
</div>
<div class="menu_header_right"> </div>
<div id="Menu_content"> <!--<a class="menu_item" href="?page=home"><span>-->
<h5>&nbsp;</h5>
<form method="post">
<input type="text" name="t1" value="search" onfocus="if(this.value=='search'){this.value='';}"onBlur="if(this.value==''){this.value='search';}"/>
<input name="sear" type="submit" class="button" id="sub" value="Go" />
</form>
<h5>&nbsp;</h5>
</span></a><br>
</div>
<div class="menu_header_left"><span class="menu_text">MEN</span></div>
<div class="menu_header_right"></div>
</div>
<div id="Menu_content">
<a class="menu_item" href="index.php?catg=1 & subcatg=Casual Shirts"><span>Casual Shirts</span></a><br>
<a class="menu_item" href="index.php?catg=1 & subcatg=Jeans"><span>Jeans</span></a><br>
<a class="menu_item" href="index.php?catg=1 & subcatg=T-Shirts"><span>T-shirts</span></a><br>
<a class="menu_item" href="index.php?catg=1 & subcatg=Shorts"><span>Shorts</span></a><br>
</div>
<div class="menu_header_left"><span class="menu_text">WOMEN</span></div>
<div class="menu_header_right"></div>
<div id="Menu_content">
<a class="menu_item" href="index.php?catg=2 & subcatg=Dresses"><span>Dresses</span></a><br>
<a class="menu_item" href="index.php?catg=2 & subcatg=churidar Suits"><span>Churidar Suits</span></a><br>
<a class="menu_item" href="index.php?catg=2 & subcatg=Kurtas"><span>Kurtas</span></a><br>
<a class="menu_item" href="index.php?catg=2 & subcatg=Office Wear"><span>Office Wear</span></a><br>
</div>
<div class="menu_header_left"><span class="menu_text">KIDS</span></div>
<div class="menu_header_right"></div>
<div id="Menu_content">
<a class="menu_item" href="index.php?catg=3 & subcatg=Baby Apparel"><span>Baby Apparel</span></a><br>
<a class="menu_item" href="index.php?catg=3 & subcatg=Girls Apparel"><span>Girls Apparel</span></a><br>
<a class="menu_item" href="index.php?catg=3 & subcatg=Boys Apparel"><span>Boys Apparel</span></a><br>
</div>
</div>
<img src="newpics/r8.jpg" width="300" height="420" /></div>
<div id="RightPart">
<?php
if($_REQUEST['se'])
{
include("search.php");
}
if($_REQUEST['con']==1)
{
include("contact.php");
}
if($_REQUEST['con']==2)
{
include("about.php");
}
if($_REQUEST['con']==3)
{
include("gallery.php");
}
if($_REQUEST['con']==11)
{
include("register.php");
}
if($_REQUEST['con']==12)
{
include("login.php");
}
if($_REQUEST['con']==13)
{
include("welcome.php");
}
if($_REQUEST['con']==14)
{
include("viewitem.php");
}
if(!($_REQUEST['catg'])and !($_REQUEST['con'])and !($_REQUEST['se']))
{
include("home.php");
}
if($_REQUEST['catg']==1)
{
if($_REQUEST['subcatg']=='Casual Shirts')
{
include("casual.php");
}
}
if($_REQUEST['catg']==1)
{
if($_REQUEST['subcatg']=='Jeans')
{
include("jeans.php");
}
}
if($_REQUEST['catg']==1)
{
if($_REQUEST['subcatg']=='T-Shirts')
{
include("tshirt.php");
}
}
if($_REQUEST['catg']==1)
{
if($_REQUEST['subcatg']=='Shorts')
{
include("shorts.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='Dresses')
{
include("dress.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='churidar Suits')
{
include("suits.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='Kurtas')
{
include("kurtas.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='Office Wear')
{
include("office.php");
}
}
if($_REQUEST['catg']==3)
{
if($_REQUEST['subcatg']=='Baby Apparel')
{
include("baby.php");
}
}
if($_REQUEST['catg']==3)
{
if($_REQUEST['subcatg']=='Girls Apparel')
{
include("girls.php");
}
}
if($_REQUEST['catg']==3)
{
if($_REQUEST['subcatg']=='Boys Apparel')
{
include("boy.php");
}
}
?>
</div>
<div class="cleaner"></div>
</div>
<div id="Bottom">
</div>
</div>
</div>
</div>
</div>
</body>
</html>
