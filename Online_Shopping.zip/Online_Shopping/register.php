<?php
include("config.php");
$title=$_REQUEST['sel1'];
$fname=$_REQUEST['t1'];
$lname=$_REQUEST['t2'];
$gen=$_REQUEST['r1'];
$id=$_REQUEST['t3'];
$pass=$_REQUEST['p1'];
$phone=$_REQUEST['t5'];
$add=$_REQUEST['t6'];
$city=$_REQUEST['t7'];
$coun=$_REQUEST['t8'];
$dob=$_REQUEST['t9'];
if($_REQUEST['sub'])
{
$sel=mysqli_query($conn,"select id from register where id='$id' ");
$arr=mysqli_fetch_array($sel);
if($arr['id']!=$id)
{
if(mysqli_query($conn,"insert into register values('$title','$fname','$lname','$gen','$id','$pass','$phone','$add','$city','$coun','$dob')"))
{
echo "<script>location.href='index.php?con=13 & wel=$id'</script>";
}
}
else
{
echo "user already exists";
}
}
?>

<html>
<head>
<script>
function fnam()
{
var fnam=/^[a-zA-Z]{3,15}$/;
if(document.f1.t1.value.search(fnam)==-1)
{
alert("enter correct  first name");
document.f1.t1.focus();
return false;
}
}
function lnam()
{
var lnam=/^[a-zA-Z]{2,15}$/;
if(document.f1.t2.value.search(lnam)==-1)
{
alert("enter correct last name");
document.f1.t2.focus();
return false;
}
}
function email()
{
var email=/^[a-zA-Z0-9-_\.]+@[a-zA-Z]+\.[a-zA-Z]{2,3}$/;
if(document.f1.t3.value.search(email)==-1)
{
alert("enter correct email");
document.f1.t3.focus();
return false;
}
}
function pass()
{
var pass=/^[a-zA-Z0-9-_]{4,16}$/;
if(document.f1.p1.value.search(pass)==-1)
{
alert("enter correct pass");
document.f1.p1.focus();
return false;
}
}
function phone()
{
var phn=/^[0-9]{9,14}$/;
if(document.f1.t5.value.search(phn)==-1)
{
alert("enter correct phone no");
document.f1.t5.focus();
return false;
}
}
function add()
{
var add=/^[a-zA-Z0-9-_]{2,15}$/;
if(document.f1.t6.value.search(add)==-1)
{
alert("enter correct address");
document.f1.t6.focus();
return false;
}
}
function city()
{
var city=/^[a-zA-Z]{4,30}$/;
if(document.f1.t7.value.search(city)==-1)
{
alert("enter correct city");
document.f1.t7.focus();
return false;
}
}
function coun()
{
var coun=/^[a-zA-Z]{4,30}$/;
if(document.f1.t8.value.search(coun)==-1)
{
alert("enter correct country");
document.f1.t8.focus();
return false;
}
}
function vali()
{
var fnam=/^[a-zA-Z]{3,15}$/;
var lnam=/^[a-zA-Z]{2,15}$/;
var email=/^[a-zA-Z0-9-_\.]+@[a-zA-Z]+\.[a-zA-Z]{2,3}$/;
var pass=/^[a-zA-Z0-9-_]{4,16}$/;
var phn=/^[0-9]{9,14}$/;
var add=/^[a-zA-Z0-9 ]{2,15}$/;
var city=/^[a-zA-Z]{4,30}$/;
var coun=/^[a-zA-Z]{4,30}$/;
if(document.f1.t1.value.search(nam)==-1)
{
alert("enter correct  first name");
document.f1.t1.focus();
return false;
}
else if(document.f1.t2.value.search(nam)==-1)
{
alert("enter correct last name");
document.f1.t2.focus();
return false;
}
else if(document.f1.t3.value.search(email)==-1)
{
alert("enter correct login name");
document.f1.t3.focus();
return false;
}
else if(document.f1.p1.value.search(pass)==-1)
{
alert("enter correct pass");
document.f1.p1.focus();
return false;
}
else if(document.f1.t5.value.search(phn)==-1)
{
alert("enter correct phone no");
document.f1.t5.focus();
return false;
}
else if(document.f1.t6.value.search(add)==-1)
{
alert("enter correct address");
document.f1.t6.focus();
return false;
}
else if(document.f1.t7.value.search(city)==-1)
{
alert("enter correct city");
document.f1.t7.focus();
return false;
}
else if(document.f1.t8.value.search(coun)==-1)
{
alert("enter correct country");
document.f1.t8.focus();
return false;
}
else
{
return true;
}
}
</script>
</head>

<body>
<div><br/><center><h2><font face="Lucida Handwriting" size="+1" color="#00CCFF">Register Yourself</font></h2></center></div>
<div>
<div style="width:25%;float:right">
<br><br><br><br><br>
<img src="usepics/7.jpg">
</div>
<br><br>
<center><div style="width:70%;float:right" align="center">
<fieldset style="background:#CC99CC;width:80%">
<br><br>
<form method="post" name="f1" onSubmit="return vali()">
<table width="400" border="0" align="center">
<tr>
<td><div align="left"><strong><font size="+1" face="Comic Sans MS">&nbspTitle:</font></strong></div></td>
<td><label>
<select name="sel1" id="sel1">
<option value="Mr.">Mr.</option>
<option value="Ms.">Ms.</option>
<option value="Mrs.">Mrs.</option>
</select>
</label></td>
</tr>
<tr>
<td width="164"><div align="left"><font size="+1" face="Comic Sans MS"><b>&nbspFirst&nbsp;Name:</b></font></div></td>
<td width="192">
<input name="t1" type="text" id="t1" onChange="return fnam()">    </td>
</tr>
<tr>
<td><div align="left"><font size="+1" face="Comic Sans MS"><strong>&nbspLast name:</strong></font></div></td>
<td><input name="t2" type="text" id="t2" onChange="return lnam()" ></td>
</tr>
<tr>
<td><div align="left"><font size="+1" face="Comic Sans MS"><b>&nbsp;Gender:</b> </font></div></td>
<td><input name="r1" type="radio" value="male">
<strong>Male</strong>
<input name="r1" type="radio" value="female">
<strong>Female</strong></td>
</tr>
<tr>
<td><div align="left"><font size="+1" face="Comic Sans MS"><b>&nbspEnter Email : </b></font></div></td>
<td><input name="t3" type="text" id="t3" onChange="return email()"></td>
</tr>
<tr>
<td><div align="left"><font size="+1" face="Comic Sans MS"><b>&nbspChoose a Password:</b> </font></div></td>
<td><input name="p1" type="password" id="p1" onChange="return pass()" size="21"></td>
</tr>
<tr> <td><div align="left"><font size="+1" face="Comic Sans MS"><b>&nbspPhone no: </b></font></div></td>
<td><input name="t5" type="text" id="t5" onChange="return phone()"></td>
</tr>
<tr>
<td><div align="left"><font size="+1" face="Comic Sans MS"><strong>&nbspAddress:</strong></font></div></td>
<td><label>
<textarea name="t6" id="t6" value="return add()" style="width:151"></textarea>
</label></td>
</tr>
<tr>
<td><div align="left"><font size="+1" face="Comic Sans MS"><strong>&nbspCity:</strong></font></div></td>
<td><input name="t7" type="text" id="t7" onChange="return city()"></td>
</tr>
<tr>
<td><div align="left"><font size="+1" face="Comic Sans MS"><strong>&nbspCountry:</strong></font></div></td>
<td><input name="t8" type="text" id="t8" onChange="return coun()"></td>
</tr>
<tr>
<td><div align="left"><strong><font size="+1" face="Comic Sans MS">&nbspDate of Birth: </font></strong></div></td>
<td><label>
<input name="t9" type="text" id="t9">
</label></td>
</tr>
<tr>
<td colspan="2"><label><br>
<center>
<input name="sub" type="submit" id="sub" value="Create my Account">
</center>
</label></td>
</tr>
 </table>
 </form>
</fieldset>
</div>
</center>
</div>
</body>
</html>
