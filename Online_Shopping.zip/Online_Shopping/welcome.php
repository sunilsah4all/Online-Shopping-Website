<html>
<div>
<div style="width:25%;float:right">
<br><br><br><br><br>
<img src="usepics/7.jpg">
</div>
<br><br>
<center><div style="width:70%;float:right" align="center">
<div><br/><center><h2><font face="Lucida Handwriting" size="+1" color="#00CCFF">Welcome User</font></h2></center></div>
<br><br><br>
<fieldset style="background:#CC99CC;width:50%">
<br><br>
<font color="#660033" size="+1" face="Comic Sans MS"><b>You are Successfully Registered!!! </b></font><br/><br/>
<font size="+1" face="Comic Sans MS" color="#660033" ><b>Your id is:</b><font color="#FF3366"><?php echo $_REQUEST['wel'];?></font><br/><br/></font>
</fieldset>
</div>
</center>
<!--<div style="width:100%;float:left"><center><b>Copyright&copy;Rahul Yadav</b></center></div>-->
</div>
</html>